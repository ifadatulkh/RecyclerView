package com.example.psi_recyclerview

data class Nama(val imgView: Int, val txtTitle: String, val txtSubTitle: String, val txtClass: String){
}